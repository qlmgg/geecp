<?php
return [
  // 接口地址
  'api_url' => 'http://api.cndns.com/',
  // 端口号
  // 'port' => 80,
];