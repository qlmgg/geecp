<?php
return [
  // 接口地址
  'api_url' => 'https://chshuju.com/api/cloudapi.asp',
  // 端口号
  'port' => 80,
];